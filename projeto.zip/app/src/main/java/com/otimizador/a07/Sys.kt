package com.otimizador.a07

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import java.util.Locale

/** Leituras simples do sistema. Tudo local, nada sai do aparelho. */
object Sys {

    fun fmt(bytes: Long): String {
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        var v = bytes.toDouble()
        var i = 0
        while (v >= 1024 && i < units.size - 1) {
            v /= 1024
            i++
        }
        return String.format(Locale.getDefault(), "%.1f %s", v, units[i])
    }

    /** Retorna (usada, total) da RAM. */
    fun ram(c: Context): Pair<Long, Long> {
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return Pair(mi.totalMem - mi.availMem, mi.totalMem)
    }

    /** Retorna (usado, total) do armazenamento interno. */
    fun storage(): Pair<Long, Long> {
        val s = StatFs(Environment.getDataDirectory().path)
        val total = s.blockCountLong * s.blockSizeLong
        val free = s.availableBlocksLong * s.blockSizeLong
        return Pair(total - free, total)
    }

    /** Retorna (porcentagem, temperatura em °C). */
    fun battery(c: Context): Pair<Int, Float> {
        val i = c.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val temp = (i?.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) ?: 0) / 10f
        val pct = if (level < 0 || scale <= 0) 0 else level * 100 / scale
        return Pair(pct, temp)
    }
}
