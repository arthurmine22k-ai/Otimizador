package com.otimizador.a07

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Monitor flutuante: RAM, bateria, temperatura e hora, por cima de qualquer app/jogo. */
class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private var label: TextView? = null
    private val handler = Handler(Looper.getMainLooper())

    private val tick = object : Runnable {
        override fun run() {
            label?.text = buildText()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        if (label == null) addOverlay()
        handler.removeCallbacks(tick)
        handler.post(tick)
        return START_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel("overlay", "Monitor flutuante", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, "overlay")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle("Monitor flutuante ativo")
            .setContentText("Abra o Otimizador A07 para desligar")
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun addOverlay() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val tv = TextView(this).apply {
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.parseColor("#99000000"))
            textSize = 12f
            setPadding(16, 8, 16, 8)
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 16
            y = 80
        }
        wm.addView(tv, lp)
        label = tv
    }

    private fun buildText(): String {
        val (used, total) = Sys.ram(this)
        val (pct, temp) = Sys.battery(this)
        val hora = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())
        val ramPct = if (total > 0) used * 100 / total else 0
        return "RAM ${ramPct}%  |  Bat ${pct}%  ${"%.1f".format(temp)}°C  |  $hora"
    }

    override fun onDestroy() {
        handler.removeCallbacks(tick)
        label?.let { runCatching { wm.removeView(it) } }
        label = null
        super.onDestroy()
    }
}
