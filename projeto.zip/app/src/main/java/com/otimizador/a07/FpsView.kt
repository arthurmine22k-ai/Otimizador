package com.otimizador.a07

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.view.Choreographer
import android.view.View

/**
 * Animação simples que mede o FPS real com que este app consegue desenhar.
 * Serve para ver a taxa de atualização da tela (ex.: 60 ou 90 Hz) e se o aparelho está engasgando.
 * NÃO mede o FPS de outros apps ou jogos (o Android não permite isso sem root).
 */
class FpsView(context: Context) : View(context) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#7C4DFF")
        strokeWidth = 12f
        strokeCap = Paint.Cap.ROUND
    }
    private var running = false
    private var frames = 0
    private var lastNs = 0L
    private var angle = 0f
    var onFps: ((Int) -> Unit)? = null

    private val callback = object : Choreographer.FrameCallback {
        override fun doFrame(frameTimeNanos: Long) {
            if (!running) return
            if (lastNs == 0L) lastNs = frameTimeNanos
            frames++
            angle += 6f
            if (frameTimeNanos - lastNs >= 1_000_000_000L) {
                onFps?.invoke(frames)
                frames = 0
                lastNs = frameTimeNanos
            }
            invalidate()
            Choreographer.getInstance().postFrameCallback(this)
        }
    }

    fun start() {
        if (running) return
        running = true
        frames = 0
        lastNs = 0L
        Choreographer.getInstance().postFrameCallback(callback)
    }

    fun stop() {
        running = false
    }

    override fun onDraw(canvas: Canvas) {
        canvas.drawColor(Color.parseColor("#1E1E2E"))
        val cx = width / 2f
        val cy = height / 2f
        canvas.save()
        canvas.rotate(angle, cx, cy)
        for (i in 0 until 8) {
            canvas.drawLine(cx, cy - 24f, cx, cy - 100f, paint)
            canvas.rotate(45f, cx, cy)
        }
        canvas.restore()
    }

    override fun onDetachedFromWindow() {
        running = false
        super.onDetachedFromWindow()
    }
}
