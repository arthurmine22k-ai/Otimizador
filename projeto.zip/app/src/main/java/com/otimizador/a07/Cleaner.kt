package com.otimizador.a07

import java.io.File

class Item(val file: File, val size: Long)

class Category(val name: String) {
    val items = mutableListOf<Item>()
    val total: Long get() = items.sumOf { it.size }
}

/**
 * Procura apenas tipos de arquivo claramente descartáveis.
 * Nunca mexe na pasta Android/ (dados de outros apps) nem em arquivos ocultos como .nomedia.
 * Nada é apagado sem o usuário marcar e confirmar.
 */
object Cleaner {

    private val tempExt = setOf("tmp", "temp", "log", "bak", "old", "chk", "dmp", "thumbdata")

    fun scan(root: File): List<Category> {
        val apks = Category("APKs (instaladores antigos)")
        val temps = Category("Temporários e logs")
        val empties = Category("Arquivos vazios")
        val thumbs = Category("Miniaturas em cache")

        fun walk(dir: File, depth: Int) {
            if (depth > 8) return
            val children = dir.listFiles() ?: return
            for (f in children) {
                if (f.isDirectory) {
                    when {
                        f.name == "Android" -> continue
                        f.name == ".thumbnails" -> thumbs.items.add(Item(f, dirSize(f)))
                        else -> walk(f, depth + 1)
                    }
                } else {
                    val ext = f.extension.lowercase()
                    val len = f.length()
                    when {
                        f.name.startsWith(".") -> continue
                        len == 0L -> empties.items.add(Item(f, 0L))
                        ext == "apk" -> apks.items.add(Item(f, len))
                        ext in tempExt -> temps.items.add(Item(f, len))
                    }
                }
            }
        }

        walk(root, 0)
        return listOf(apks, temps, empties, thumbs)
    }

    private fun dirSize(d: File): Long =
        d.walkTopDown().filter { it.isFile }.sumOf { it.length() }

    /** Retorna (quantidade apagada, bytes liberados). */
    fun delete(items: List<Item>): Pair<Int, Long> {
        var n = 0
        var bytes = 0L
        for (i in items) {
            val ok = if (i.file.isDirectory) i.file.deleteRecursively() else i.file.delete()
            if (ok) {
                n++
                bytes += i.size
            }
        }
        return Pair(n, bytes)
    }
}
