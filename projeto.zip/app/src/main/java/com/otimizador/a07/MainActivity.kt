package com.otimizador.a07

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.Button
import android.widget.CheckBox
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private val handler = Handler(Looper.getMainLooper())

    private lateinit var status: TextView
    private lateinit var results: LinearLayout
    private lateinit var cleanInfo: TextView
    private lateinit var fpsText: TextView
    private lateinit var fpsView: FpsView
    private lateinit var overlayBtn: Button
    private lateinit var fpsBtn: Button

    private val checks = mutableListOf<Pair<CheckBox, Category>>()
    private var overlayOn = false
    private var fpsOn = false

    private val refresh = object : Runnable {
        override fun run() {
            status.text = statusText()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(32), dp(16), dp(32))
        }
        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#12121A"))
            addView(root)
        })

        root.addView(tv("Otimizador A07", 26f, Color.WHITE, true))
        root.addView(tv("100% local: sem internet, sem anúncios, sem rastreadores.", 13f, Color.parseColor("#9AA0B4")))

        // ---- Status em tempo real ----
        val statusCard = card(root, "Status do aparelho")
        status = tv("")
        statusCard.addView(status)

        // ---- Limpeza ----
        val cleanCard = card(root, "Limpeza de arquivos")
        cleanCard.addView(tv("Procura APKs antigos, temporários, logs, arquivos vazios e miniaturas em cache. Nada é apagado sem você marcar e confirmar.", 13f, Color.parseColor("#9AA0B4")))
        cleanCard.addView(btn("Escanear arquivos inúteis") { scan() })
        results = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        cleanCard.addView(results)
        cleanInfo = tv("")
        cleanCard.addView(cleanInfo)
        cleanCard.addView(btn("Apagar selecionados") { confirmDelete() })
        cleanCard.addView(btn("Limpar cache deste app") {
            cacheDir.listFiles()?.forEach { it.deleteRecursively() }
            externalCacheDir?.listFiles()?.forEach { it.deleteRecursively() }
            toast("Cache do app limpo")
        })
        cleanCard.addView(btn("Limpar cache de outros apps (Cuidados do aparelho)") {
            val i = packageManager.getLaunchIntentForPackage("com.samsung.android.lool")
            if (i != null) startActivity(i) else openIntent(Intent(Settings.ACTION_INTERNAL_STORAGE_SETTINGS))
        })

        // ---- Monitor flutuante ----
        val overlayCard = card(root, "Monitor flutuante")
        overlayCard.addView(tv("Mostra RAM, bateria, temperatura e hora por cima dos jogos.", 13f, Color.parseColor("#9AA0B4")))
        overlayBtn = btn("Ligar monitor flutuante") { toggleOverlay() }
        overlayCard.addView(overlayBtn)

        // ---- Teste de FPS ----
        val fpsCard = card(root, "FPS em tempo real")
        fpsCard.addView(tv("Mede o FPS que o aparelho consegue desenhar agora (a animação abaixo). O Android não permite medir o FPS de outros jogos sem root.", 13f, Color.parseColor("#9AA0B4")))
        fpsText = tv("FPS: --", 22f, Color.parseColor("#69F0AE"), true)
        fpsCard.addView(fpsText)
        fpsView = FpsView(this)
        fpsView.onFps = { fps -> fpsText.text = "FPS: $fps" }
        fpsCard.addView(fpsView, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(200)))
        fpsBtn = btn("Iniciar teste de FPS") { toggleFps() }
        fpsCard.addView(fpsBtn)

        // ---- Jogos e desempenho ----
        val boostCard = card(root, "Jogos e desempenho")
        boostCard.addView(tv("Nenhum app comum consegue acelerar o aparelho por mágica. Estes atalhos levam às opções que realmente fazem diferença.", 13f, Color.parseColor("#9AA0B4")))
        boostCard.addView(btn("Abrir Game Launcher (Samsung)") {
            val i = packageManager.getLaunchIntentForPackage("com.samsung.android.game.gamehome")
            if (i != null) startActivity(i) else toast("Game Launcher não encontrado")
        })
        boostCard.addView(btn("Modo de energia / desempenho") {
            openIntent(Intent(Settings.ACTION_BATTERY_SAVER_SETTINGS))
        })
        boostCard.addView(btn("Apps instalados (desative os que não usa)") {
            openIntent(Intent(Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS))
        })
        boostCard.addView(btn("Opções do desenvolvedor") {
            openIntent(Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS))
        })
        boostCard.addView(tv(
            "Dicas antes de jogar:\n" +
                "• Feche os apps recentes.\n" +
                "• Use o modo de desempenho e evite jogar carregando.\n" +
                "• Temperatura alta derruba o FPS: deixe o aparelho em lugar fresco.\n" +
                "• Mantenha pelo menos 15% do armazenamento livre.\n" +
                "• Nas opções do desenvolvedor, escalas de animação em 0,5x deixam o sistema mais ágil.",
            13f, Color.parseColor("#C9CCDA")
        ))
    }

    override fun onResume() {
        super.onResume()
        handler.post(refresh)
    }

    override fun onPause() {
        handler.removeCallbacks(refresh)
        if (fpsOn) toggleFps()
        super.onPause()
    }

    // ---------- Ações ----------

    private fun scan() {
        if (!Environment.isExternalStorageManager()) {
            toast("Ative 'Acesso a todos os arquivos' para o app e volte")
            openIntent(Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        cleanInfo.text = "Procurando..."
        results.removeAllViews()
        checks.clear()
        Thread {
            val cats = Cleaner.scan(Environment.getExternalStorageDirectory())
            runOnUiThread { showResults(cats) }
        }.start()
    }

    private fun showResults(cats: List<Category>) {
        results.removeAllViews()
        checks.clear()
        for (c in cats) {
            val cb = CheckBox(this).apply {
                text = "${c.name}: ${c.items.size} itens (${Sys.fmt(c.total)})"
                setTextColor(Color.WHITE)
                isEnabled = c.items.isNotEmpty()
            }
            results.addView(cb)
            checks.add(Pair(cb, c))
        }
        cleanInfo.text = "Total encontrado: ${Sys.fmt(cats.sumOf { it.total })}"
    }

    private fun confirmDelete() {
        val selected = checks.filter { it.first.isChecked }.flatMap { it.second.items }
        if (selected.isEmpty()) {
            toast("Marque o que deseja apagar")
            return
        }
        val size = selected.sumOf { it.size }
        AlertDialog.Builder(this)
            .setTitle("Apagar ${selected.size} itens?")
            .setMessage("Libera ${Sys.fmt(size)}. Isso não pode ser desfeito.")
            .setPositiveButton("Apagar") { _, _ ->
                Thread {
                    val r = Cleaner.delete(selected)
                    runOnUiThread {
                        toast("Apagados ${r.first} itens (${Sys.fmt(r.second)})")
                        scan()
                    }
                }.start()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun toggleOverlay() {
        if (overlayOn) {
            stopService(Intent(this, OverlayService::class.java))
            overlayOn = false
            overlayBtn.text = "Ligar monitor flutuante"
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            toast("Permita 'Exibir sobre outros apps' e volte")
            openIntent(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        startForegroundService(Intent(this, OverlayService::class.java))
        overlayOn = true
        overlayBtn.text = "Desligar monitor flutuante"
    }

    private fun toggleFps() {
        if (fpsOn) {
            fpsView.stop()
            fpsOn = false
            fpsBtn.text = "Iniciar teste de FPS"
        } else {
            fpsView.start()
            fpsOn = true
            fpsBtn.text = "Parar teste de FPS"
        }
    }

    private fun statusText(): String {
        val (ru, rt) = Sys.ram(this)
        val (su, st) = Sys.storage()
        val (bp, bt) = Sys.battery(this)
        val hz = display?.refreshRate ?: 0f
        return "Aparelho: ${Build.MANUFACTURER} ${Build.MODEL} (Android ${Build.VERSION.RELEASE})\n" +
            "RAM: ${Sys.fmt(ru)} / ${Sys.fmt(rt)} (${if (rt > 0) ru * 100 / rt else 0}%)\n" +
            "Armazenamento: ${Sys.fmt(su)} / ${Sys.fmt(st)} (${if (st > 0) su * 100 / st else 0}%)\n" +
            "Bateria: $bp%  •  ${"%.1f".format(bt)}°C\n" +
            "Tela: ${"%.0f".format(hz)} Hz\n" +
            "Núcleos de CPU: ${Runtime.getRuntime().availableProcessors()}"
    }

    // ---------- Helpers de interface ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun openIntent(i: Intent) {
        try {
            startActivity(i)
        } catch (e: ActivityNotFoundException) {
            toast("Não disponível neste aparelho")
        }
    }

    private fun tv(s: String, size: Float = 14f, color: Int = Color.WHITE, bold: Boolean = false) =
        TextView(this).apply {
            text = s
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, dp(4), 0, dp(4))
        }

    private fun btn(s: String, onClick: () -> Unit) = Button(this).apply {
        text = s
        isAllCaps = false
        setOnClickListener { onClick() }
    }

    private fun card(parent: LinearLayout, title: String): LinearLayout {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(14), dp(14), dp(14))
            setBackgroundColor(Color.parseColor("#1E1E2E"))
        }
        c.addView(tv(title, 18f, Color.parseColor("#B39DFF"), true))
        val lp = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(12) }
        parent.addView(c, lp)
        return c
    }
}
